package hibernate.UserMngtSys.demo.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class CompanyType {
	@Id
	private int typeID;
	public int getTypeID() {
		return typeID;
	}
	public void setTypeID(int typeID) {
		this.typeID = typeID;
	}
	public CompanyType() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "CompanyType [typeID=" + typeID + ", TyprName=" + TyprName + "]";
	}
	public String getTyprName() {
		return TyprName;
	}
	public void setTyprName(String typrName) {
		TyprName = typrName;
	}
	private String TyprName;
	
}
