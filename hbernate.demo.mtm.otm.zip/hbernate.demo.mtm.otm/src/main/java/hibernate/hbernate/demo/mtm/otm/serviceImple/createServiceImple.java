package hibernate.hbernate.demo.mtm.otm.serviceImple;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;

import hibernate.hbernate.demo.mtm.otm.dbconnection.DBConnection;
import hibernate.hbernate.demo.mtm.otm.entity.Deptt;
import hibernate.hbernate.demo.mtm.otm.entity.Emp;
import hibernate.hbernate.demo.mtm.otm.service.createservice;

public class createServiceImple implements createservice{

	@Override
	public void adddata() {
		// TODO Auto-generated method stub
		EntityManager eManager=DBConnection.dbconn().createEntityManager();
		eManager.getTransaction().begin();
		
		Emp emp1=new Emp();
		emp1.setEmpid(101);
		emp1.setEmpname(" afe");
		emp1.setEmpAdd("satara");
		
		Emp emp2=new Emp();
		emp2.setEmpid(102);
		emp2.setEmpname("var");
		emp2.setEmpAdd("Vita");
		
		Emp emp3=new Emp();
		emp3.setEmpid(103);
		emp3.setEmpname("vwt4r");
		emp3.setEmpAdd("Parbhani");
		
		Emp emp4=new Emp();
		emp4.setEmpid(104);
		emp4.setEmpname("vats");
		emp4.setEmpAdd("Pune");
		
		ArrayList<Emp> emps1=new ArrayList<Emp>();
		emps1.add(emp1);
		emps1.add(emp2);
		
		
		ArrayList<Emp> emps2=new ArrayList<Emp>();
		emps2.add(emp3);
		emps2.add(emp4);		
		
		Deptt deptt1=new Deptt();
		deptt1.setDeptid(201);
		deptt1.setDeptname("IT");
		deptt1.setDeptAdd("Kolhapur");
		
		Deptt deptt2=new Deptt();
		deptt2.setDeptid(202);
		deptt2.setDeptname("DS");
		deptt2.setDeptAdd("Solapur");

		Deptt deptt3=new Deptt();
		deptt3.setDeptid(203);
		deptt3.setDeptname("AI");
		deptt3.setDeptAdd("aalandi");
		
		Deptt deptt4=new Deptt();
		deptt4.setDeptid(204);
		deptt4.setDeptname("DEV");
		deptt4.setDeptAdd("bindi");
		
		ArrayList<Deptt> deptts1=new ArrayList<Deptt>();
		deptts1.add(deptt1);
		deptts1.add(deptt2);
		
		ArrayList<Deptt> deptts2=new ArrayList<Deptt>();
		deptts2.add(deptt3);
		deptts2.add(deptt4);
		
		emp1.setDeptts(deptts1);
		emp2.setDeptts(deptts2);
		emp3.setDeptts(deptts1);
		emp4.setDeptts(deptts2);
		
		
		
		deptt1.setEmps(emps1);
		deptt2.setEmps(emps1);
		deptt3.setEmps(emps2);
		deptt4.setEmps(emps2);
		
		eManager.persist(emp1);
		eManager.persist(emp2);
		eManager.persist(emp3);
		eManager.persist(emp4);
		
		eManager.persist(deptt1);
		eManager.persist(deptt2);
		eManager.persist(deptt3);
		eManager.persist(deptt4);
		
		
		System.out.println("Data Inserted Successfully");
		
		eManager.getTransaction().commit();
		eManager.close();
		
	}

}
